// import 'package:flutter/material.dart';

// void main() {
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: ProfilePage(),
//     );
//   }
// }

// class ProfilePage extends StatelessWidget {
//   final List<String> posts = List.generate(
//     12,
//     (index) => "https://picsum.photos/300?random=$index",
//   );

//   final List<Map<String, String>> highlights = [
//     {"title": "New", "img": "https://picsum.photos/100?1"},
//     {"title": "Travels", "img": "https://picsum.photos/100?2"},
//     {"title": "Foodie", "img": "https://picsum.photos/100?3"},
//     {"title": "Coding", "img": "https://picsum.photos/100?4"},
//     {"title": "Hobbies", "img": "https://picsum.photos/100?5"},
//   ];

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("ch_asnavvi"), // GANTI USERNAME
//         actions: [
//           Icon(Icons.add_box_outlined),
//           SizedBox(width: 15),
//           Icon(Icons.menu),
//           SizedBox(width: 10),
//         ],
//       ),
//       body: SingleChildScrollView(
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [

//             // ===== PROFILE =====
//             Padding(
//               padding: EdgeInsets.all(16),
//               child: Row(
//                 children: [
//                   CircleAvatar(
//                     radius: 40,
//                     backgroundImage:
//                         NetworkImage("https://picsum.photos/200"),
//                   ),
//                   SizedBox(width: 20),
//                   Expanded(
//                     child: Row(
//                       mainAxisAlignment:
//                           MainAxisAlignment.spaceAround,
//                       children: [
//                         buildStat("123", "Posts"),
//                         buildStat("456k", "Followers"),
//                         buildStat("789", "Following"),
//                       ],
//                     ),
//                   )
//                 ],
//               ),
//             ),

//             // ===== BIO =====
//             Padding(
//               padding: EdgeInsets.symmetric(horizontal: 16),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text("Choerun Asnawi",
//                       style:
//                           TextStyle(fontWeight: FontWeight.bold)),
//                   SizedBox(height: 4),
//                   Text(
//                       "Lecturer @ Universitas Jenderal Achmad Yani Yogyakarta"),
//                   SizedBox(height: 4),
//                   Text(
//                     "asnavi.web.id",
//                     style: TextStyle(color: Colors.blue),
//                   ),
//                 ],
//               ),
//             ),

//             SizedBox(height: 10),

//             // ===== BUTTON =====
//             Padding(
//               padding: EdgeInsets.symmetric(horizontal: 16),
//               child: Row(
//                 children: [
//                   Expanded(
//                     child: OutlinedButton(
//                       onPressed: () {},
//                       child: Text("Edit Profile"),
//                     ),
//                   ),
//                   SizedBox(width: 10),
//                   Expanded(
//                     child: OutlinedButton(
//                       onPressed: () {},
//                       child: Text("Share Profile"),
//                     ),
//                   ),
//                 ],
//               ),
//             ),

//             SizedBox(height: 15),

//             // ===== HIGHLIGHTS =====
//             Padding(
//               padding: EdgeInsets.symmetric(horizontal: 16),
//               child: SizedBox(
//                 height: 90,
//                 child: ListView.builder(
//                   scrollDirection: Axis.horizontal,
//                   itemCount: highlights.length,
//                   itemBuilder: (context, index) {
//                     return Padding(
//                       padding: EdgeInsets.only(right: 12),
//                       child: Column(
//                         children: [
//                           CircleAvatar(
//                             radius: 30,
//                             backgroundImage: NetworkImage(
//                                 highlights[index]["img"]!),
//                           ),
//                           SizedBox(height: 5),
//                           Text(
//                             highlights[index]["title"]!,
//                             style: TextStyle(fontSize: 12),
//                           )
//                         ],
//                       ),
//                     );
//                   },
//                 ),
//               ),
//             ),

//             Divider(),

//             // ===== TAB =====
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceAround,
//               children: [
//                 Icon(Icons.grid_on),
//                 Icon(Icons.video_collection_outlined),
//                 Icon(Icons.person_outline),
//               ],
//             ),

//             SizedBox(height: 10),

//             // ===== GRID =====
//             GridView.builder(
//               shrinkWrap: true,
//               physics: NeverScrollableScrollPhysics(),
//               itemCount: posts.length,
//               gridDelegate:
//                   SliverGridDelegateWithFixedCrossAxisCount(
//                 crossAxisCount: 3,
//                 crossAxisSpacing: 2,
//                 mainAxisSpacing: 2,
//               ),
//               itemBuilder: (context, index) {
//                 return Image.network(
//                   posts[index],
//                   fit: BoxFit.cover,
//                 );
//               },
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget buildStat(String number, String label) {
//     return Column(
//       children: [
//         Text(number,
//             style: TextStyle(
//                 fontWeight: FontWeight.bold, fontSize: 16)),
//         Text(label),
//       ],
//     );
//   }
// }

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

// --- 1. Data Models ---

class Users {
  Users({
    required this.users,
    required this.total,
    required this.skip,
    required this.limit,
  });

  final List<User> users;
  final int? total;
  final int? skip;
  final int? limit;

  factory Users.fromJson(Map<String, dynamic> json) {
    return Users(
      users: json["users"] == null
          ? []
          : List<User>.from(json["users"].map((x) => User.fromJson(x))),
      total: json["total"],
      skip: json["skip"],
      limit: json["limit"],
    );
  }

  Map<String, dynamic> toJson() => {
    "users": users.map((x) => x.toJson()).toList(),
    "total": total,
    "skip": skip,
    "limit": limit,
  };
}

class User {
  User({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.maidenName,
    required this.age,
    required this.gender,
    required this.email,
    required this.phone,
    required this.username,
    required this.password,
    required this.birthDate,
    required this.image,
    required this.bloodGroup,
    required this.height,
    required this.weight,
    required this.eyeColor,
    required this.hair,
    required this.ip,
    required this.address,
    required this.macAddress,
    required this.university,
    required this.bank,
    required this.company,
    required this.ein,
    required this.ssn,
    required this.userAgent,
    required this.crypto,
    required this.role,
  });

  final int? id;
  final String? firstName;
  final String? lastName;
  final String? maidenName;
  final int? age;
  final String? gender;
  final String? email;
  final String? phone;
  final String? username;
  final String? password;
  final String? birthDate;
  final String? image;
  final String? bloodGroup;
  final double? height;
  final double? weight;
  final String? eyeColor;
  final Hair? hair;
  final String? ip;
  final Address? address;
  final String? macAddress;
  final String? university;
  final Bank? bank;
  final Company? company;
  final String? ein;
  final String? ssn;
  final String? userAgent;
  final Crypto? crypto;
  final String? role;

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json["id"],
      firstName: json["firstName"],
      lastName: json["lastName"],
      maidenName: json["maidenName"],
      age: json["age"],
      gender: json["gender"],
      email: json["email"],
      phone: json["phone"],
      username: json["username"],
      password: json["password"],
      birthDate: json["birthDate"],
      image: json["image"],
      bloodGroup: json["bloodGroup"],
      height: (json["height"] as num?)?.toDouble(),
      weight: (json["weight"] as num?)?.toDouble(),
      eyeColor: json["eyeColor"],
      hair: json["hair"] == null ? null : Hair.fromJson(json["hair"]),
      ip: json["ip"],
      address: json["address"] == null
          ? null
          : Address.fromJson(json["address"]),
      macAddress: json["macAddress"],
      university: json["university"],
      bank: json["bank"] == null ? null : Bank.fromJson(json["bank"]),
      company: json["company"] == null
          ? null
          : Company.fromJson(json["company"]),
      ein: json["ein"],
      ssn: json["ssn"],
      userAgent: json["userAgent"],
      crypto: json["crypto"] == null ? null : Crypto.fromJson(json["crypto"]),
      role: json["role"],
    );
  }

  Map<String, dynamic> toJson() => {
    "id": id,
    "firstName": firstName,
    "lastName": lastName,
    "maidenName": maidenName,
    "age": age,
    "gender": gender,
    "email": email,
    "phone": phone,
    "username": username,
    "password": password,
    "birthDate": birthDate,
    "image": image,
    "bloodGroup": bloodGroup,
    "height": height,
    "weight": weight,
    "eyeColor": eyeColor,
    "hair": hair?.toJson(),
    "ip": ip,
    "address": address?.toJson(),
    "macAddress": macAddress,
    "university": university,
    "bank": bank?.toJson(),
    "company": company?.toJson(),
    "ein": ein,
    "ssn": ssn,
    "userAgent": userAgent,
    "crypto": crypto?.toJson(),
    "role": role,
  };
}

class Address {
  Address({
    required this.address,
    required this.city,
    required this.state,
    required this.stateCode,
    required this.postalCode,
    required this.coordinates,
    required this.country,
  });

  final String? address;
  final String? city;
  final String? state;
  final String? stateCode;
  final String? postalCode;
  final Coordinates? coordinates;
  final String? country;

  factory Address.fromJson(Map<String, dynamic> json) {
    return Address(
      address: json["address"],
      city: json["city"],
      state: json["state"],
      stateCode: json["stateCode"],
      postalCode: json["postalCode"],
      coordinates: json["coordinates"] == null
          ? null
          : Coordinates.fromJson(json["coordinates"]),
      country: json["country"],
    );
  }

  Map<String, dynamic> toJson() => {
    "address": address,
    "city": city,
    "state": state,
    "stateCode": stateCode,
    "postalCode": postalCode,
    "coordinates": coordinates?.toJson(),
    "country": country,
  };
}

class Coordinates {
  Coordinates({required this.lat, required this.lng});

  final double? lat;
  final double? lng;

  factory Coordinates.fromJson(Map<String, dynamic> json) {
    return Coordinates(
      lat: (json["lat"] as num?)?.toDouble(),
      lng: (json["lng"] as num?)?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() => {"lat": lat, "lng": lng};
}

class Bank {
  Bank({
    required this.cardExpire,
    required this.cardNumber,
    required this.cardType,
    required this.currency,
    required this.iban,
  });

  final String? cardExpire;
  final String? cardNumber;
  final String? cardType;
  final String? currency;
  final String? iban;

  factory Bank.fromJson(Map<String, dynamic> json) {
    return Bank(
      cardExpire: json["cardExpire"],
      cardNumber: json["cardNumber"],
      cardType: json["cardType"],
      currency: json["currency"],
      iban: json["iban"],
    );
  }

  Map<String, dynamic> toJson() => {
    "cardExpire": cardExpire,
    "cardNumber": cardNumber,
    "cardType": cardType,
    "currency": currency,
    "iban": iban,
  };
}

class Company {
  Company({
    required this.department,
    required this.name,
    required this.title,
    required this.address,
  });

  final String? department;
  final String? name;
  final String? title;
  final Address? address;

  factory Company.fromJson(Map<String, dynamic> json) {
    return Company(
      department: json["department"],
      name: json["name"],
      title: json["title"],
      address: json["address"] == null
          ? null
          : Address.fromJson(json["address"]),
    );
  }

  Map<String, dynamic> toJson() => {
    "department": department,
    "name": name,
    "title": title,
    "address": address?.toJson(),
  };
}

class Crypto {
  Crypto({required this.coin, required this.wallet, required this.network});

  final String? coin;
  final String? wallet;
  final String? network;

  factory Crypto.fromJson(Map<String, dynamic> json) {
    return Crypto(
      coin: json["coin"],
      wallet: json["wallet"],
      network: json["network"],
    );
  }

  Map<String, dynamic> toJson() => {
    "coin": coin,
    "wallet": wallet,
    "network": network,
  };
}

class Hair {
  Hair({required this.color, required this.type});

  final String? color;
  final String? type;

  factory Hair.fromJson(Map<String, dynamic> json) {
    return Hair(color: json["color"], type: json["type"]);
  }

  Map<String, dynamic> toJson() => {"color": color, "type": type};
}


// --- 2. API Services ---

class UserApiService {
  static const String _baseUrl = 'https://dummyjson.com';

  // Changed UsersResponse to Users
  static Future<Users> fetchUsers() async {
    final response = await http.get(Uri.parse('$_baseUrl/users'));
    if (response.statusCode == 200) {
      // Changed UsersResponse to Users
      return Users.fromJson(json.decode(response.body));
    } else {
      throw Exception('Gagal memuat pengguna');
    }
  }

  static Future<User> fetchUserById(int id) async {
    final response = await http.get(Uri.parse('$_baseUrl/users/$id'));
    if (response.statusCode == 200) {
      return User.fromJson(json.decode(response.body));
    } else {
      throw Exception('Gagal memuat detail pengguna');
    }
  }
}

// --- 3. Providers ---

class UserListProvider extends ChangeNotifier {
  // Changed UsersResponse to Users
  late Future<Users> _future;

  UserListProvider() {
    _future = UserApiService.fetchUsers();
  }

  // Changed UsersResponse to Users
  Future<Users> get future => _future;

  void refresh() {
    _future = UserApiService.fetchUsers();
    notifyListeners();
  }
}

class UserDetailProvider extends ChangeNotifier {
  final int id;
  late Future<User> _future;

  UserDetailProvider(this.id) {
    _future = UserApiService.fetchUserById(id);
  }

  Future<User> get future => _future;

  void refresh() {
    _future = UserApiService.fetchUserById(id);
    notifyListeners();
  }
}

// --- 4. Main Application ---

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => UserListProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'User Directory',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.indigo, useMaterial3: true),
      home: const UserListScreen(),
    );
  }
}

// --- 5. User List Screen ---

class UserListScreen extends StatelessWidget {
  const UserListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final watcher = context.watch<UserListProvider>();
    final reader = context.read<UserListProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('User Directory'),
        actions: [
          IconButton(onPressed: reader.refresh, icon: const Icon(Icons.refresh))
        ],
      ),
      // Changed UsersResponse to Users
      body: FutureBuilder<Users>(
        future: watcher.future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (snapshot.hasData) {
            final users = snapshot.data!.users;
            return ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: users.length,
              itemBuilder: (context, index) => UserCard(user: users[index]),
            );
          }
          return const Center(child: Text('No data'));
        },
      ),
    );
  }
}

// --- 6. User Card Widget ---

class UserCard extends StatelessWidget {
  final User user;
  const UserCard({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: CircleAvatar(backgroundImage: NetworkImage(user.image!)), // Added null safety !
        title: Text('${user.firstName} ${user.lastName}'),
        subtitle: Text(user.email!), // Added null safety !
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => UserDetailScreen(id: user.id!)), // Added null safety !
        ),
      ),
    );
  }
}

// --- 7. User Detail Screen ---

class UserDetailScreen extends StatelessWidget {
  final int id;
  const UserDetailScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => UserDetailProvider(id),
      child: Consumer<UserDetailProvider>(
        builder: (context, provider, _) => FutureBuilder<User>(
          future: provider.future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Scaffold(body: Center(child: CircularProgressIndicator()));
            } else if (snapshot.hasData) {
              final user = snapshot.data!;
              return Scaffold(
                appBar: AppBar(title: Text(user.username!)), // Added null safety !
                body: Column(
                  children: [
                    const SizedBox(height: 20),
                    Center(
                      child: CircleAvatar(
                        radius: 60,
                        backgroundImage: NetworkImage(user.image!), // Added null safety !
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text('${user.firstName} ${user.lastName}',
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                    Text(user.email!, style: const TextStyle(color: Colors.grey)), // Added null safety !
                    const Divider(height: 40),
                    ListTile(
                      leading: const Icon(Icons.school),
                      title: const Text('University'),
                      subtitle: Text(user.university!), // Added null safety !
                    ),
                    ListTile(
                      leading: const Icon(Icons.work),
                      title: const Text('Company'),
                      subtitle: Text(user.company?.name ?? 'N/A'),
                    ),
                  ],
                ),
              );
            }
            return const Scaffold(body: Center(child: Text('Error loading detail')));
          },
        ),
      ),
    );
  }
}