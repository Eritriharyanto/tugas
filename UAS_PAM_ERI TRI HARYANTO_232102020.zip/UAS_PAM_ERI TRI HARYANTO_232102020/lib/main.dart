import 'dart:convert';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

late List<CameraDescription> cameras;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  cameras = await availableCameras();

  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MahasiswaPage(),
    ),
  );
}

class MahasiswaPage extends StatefulWidget {
  const MahasiswaPage({super.key});

  @override
  State<MahasiswaPage> createState() => _MahasiswaPageState();
}

class _MahasiswaPageState extends State<MahasiswaPage> {
  final npmController = TextEditingController();
  final namaController = TextEditingController();
  final searchController = TextEditingController();
  late CameraController controller;
  XFile? foto;
  List data = [];

  @override
  void initState() {
    super.initState();

    controller = CameraController(
      cameras[0],
      ResolutionPreset.medium,
    );

    controller.initialize().then((_) {
      if (mounted) {
        setState(() {});
      }
    });

    getData();
  }

  Future<void> ambilFoto() async {
    final hasil = await controller.takePicture();
    setState(() {
      foto = hasil;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Foto berhasil diambil'),
      ),
    );
  }

  Future<void> getData() async {
    final response = await http.get(
      Uri.parse('http://asnawi.web.id/mhsapi/'),
    );
    final hasil = jsonDecode(response.body);
    setState(() {
      data = hasil['data'];
    });
  }

  Future<void> getDataByNpm(String npm) async {
    final response = await http.get(
      Uri.parse('http://asnawi.web.id/mhsapi/?npm=$npm'),
    );
    final hasil = jsonDecode(response.body);
    setState(() {
      data = hasil['data'];
    });
  }

  Future<void> simpanData() async {
    if (foto == null) return;
    if (npmController.text.isEmpty || namaController.text.isEmpty) return;

    final bytes = await foto!.readAsBytes();
    final fotoBase64 = base64Encode(bytes);

    await http.post(
      Uri.parse('http://asnawi.web.id/mhsapi/'),
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        "npm": npmController.text,
        "nama": namaController.text,
        "foto": fotoBase64,
      }),
    );

    npmController.clear();
    namaController.clear();
    setState(() => foto = null);

    getData();
  }

  @override
  void dispose() {
    controller.dispose();
    npmController.dispose();
    namaController.dispose();
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!controller.value.isInitialized) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mahasiswa'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(10),
              children: [
                Center(
                  child: SizedBox(
                    height: 200,
                    width: 300,
                    child: ClipRect(
                      child: CameraPreview(controller),
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                Center(
                  child: ElevatedButton(
                    onPressed: ambilFoto,
                    child: const Text('Ambil Foto'),
                  ),
                ),


                if (foto != null)
                  Column(
                    children: [
                      const Text(
                        'Hasil Foto',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 5),
                      SizedBox(
                        height: 150,
                        child: Image.network(
                          foto!.path,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                  ),

                TextField(
                  controller: npmController,
                  decoration: const InputDecoration(
                    labelText: 'NPM',
                  ),
                ),

                TextField(
                  controller: namaController,
                  decoration: const InputDecoration(
                    labelText: 'Nama',
                  ),
                ),

                const SizedBox(height: 10),

                Center(
                  child: ElevatedButton(
                    onPressed: simpanData,
                    child: const Text('Simpan'),
                  ),
                ),

                const Divider(),

                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: searchController,
                        decoration: const InputDecoration(
                          labelText: 'Cari NPM',
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        if (searchController.text.isEmpty) {
                          getData();
                        } else {
                          getDataByNpm(searchController.text);
                        }
                      },
                      icon: const Icon(Icons.search),
                    ),
                  ],
                ),

                const SizedBox(height: 5),

                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      leading: data[index]['foto'] != null
                          ? Image.network(
                              'http://asnawi.web.id/mhsapi/${data[index]['foto']}',
                              width: 50,
                              height: 50,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) =>
                                  const Icon(Icons.person),
                            )
                          : const Icon(Icons.person),
                      title: Text(data[index]['npm'] ?? ''),
                      subtitle: Text(data[index]['nama'] ?? ''),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}