package com.example.uas_mahasiswa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
